﻿using DemoProject.DB;
using DemoProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DemoProject.Controllers
{
    public class RegisterBoatController : Controller
    {
        db _dblayer;
        public RegisterBoatController()
        {
            _dblayer = new db();
        }
        public ActionResult Index()
        {
            return View();
        }


        public JsonResult getAll()
        {
          
                var boatList = _dblayer.GetBoat();
                return Json(boatList, JsonRequestBehavior.AllowGet);
            
        }

       
        public string AddBoat(RegisterBoat bt)
        {
            string boatList = string.Empty;
            if (bt != null)
            {
                boatList ="Boat no is "+ _dblayer.SaveBoat(bt);

            }
            else
            {
                return "Invalid Record";
            }

            return boatList;
        }


    }
}