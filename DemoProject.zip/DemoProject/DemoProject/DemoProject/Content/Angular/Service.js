﻿app.service("MyService", function ($http) {

   
    this.getBoat = function () {
      
        return $http.get("RegisterBoat/GetAll");
    };

   
    this.AddBoat = function (Register) {
       
        var response = $http({
            method: "post",
            url: "RegisterBoat/AddBoat",
            data: JSON.stringify(Register),
            dataType: "json"
        });
      
        return response;
    }

   
});

app.service("BookService", function ($http) {

    this.GetBookBoat = function () {

        return $http.get("BookBoat/GetAll");
    };
   


    this.BookBoat = function (Register) {

        var response = $http({
            method: "post",
            url: "BookBoat/BookBoat",
            data: JSON.stringify(Register),
            dataType: "json"
        });

        return response;
    }


});

app.service("RentCalculation", function ($http) {

    //this.GetPriceBoat = function (CalculateTimePrice) {

    //    return $http.get("RentCalculation/GetAll");
    //};

    //this. = function (CalculateTimePrice) {

    //    var response = $http({
    //        method: "post",
    //        url: "RentCalculation/GetAll",
    //        data: JSON.stringify(CalculateTimePrice),
    //        dataType: "json"
    //    });

    //    return response;
    //}

    this.GetPriceBoat = function (BN) {
       
        var response = $http({
            method: "post",
            url: "RentCalculation/Getprice",
            data: JSON.stringify(BN),
            dataType: "json"
        });

        return response;
    }

});