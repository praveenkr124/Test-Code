﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoProject.Models
{
    public class CalculateTimePrice
    {
        public double TotalRentHour { get; set; }
        public double TotalRentPrice { get; set; }
        public int BoatNo { get; set; }
    }
}