﻿app.controller("BookBoatController", function ($scope, BookService) {   

    GetBookBoat();

    function GetBookBoat() {

        var getData = BookService.GetBookBoat();

        getData.then(function (emp) {
            $scope.AllBoat = emp.data;
        }, function () {
            alert('Error in getting records');
        });
    }

    $scope.BookBoat = function () {
        var BookBoat = {
            BoatNo: $scope.BoatNo,
            CustomerName: $scope.CustomerName,
            RentedHour: $scope.RentedHour
        };
        var getData = BookService.BookBoat(BookBoat);
        getData.then(function (msg) {
            GetBookBoat();
            alert(msg.data);
            ClearFields();
        }, function () {
            alert('Error in adding record');
        });

    }


    function ClearFields() {
        $scope.BoatNo = "";
        $scope.CustomerName = "";
        $scope.RentedHour = "";

    }
});