﻿app.controller('RegisterController', function ($scope, angularService) {
    //$scope.btnSave = "Save";



    //$scope.savedata = function () {

    //    $scope.btnSave = "Please wait...!";

    //    $http({

    //        method: 'POST',

    //        url: '/RegisterBoat/Register',

    //        data: $scope.Register

    //    }).then(function (res) {

    //        $scope.btnSave = "Save";

    //        $scope.Register = null;

    //        alert(res.data);

    //    }), function (error) {

    //        alert('Failed');

    //    };

    //}


    GetAllBoat();
    //To Get All Records  
    function GetAllBoat() {
        var getData = angularService.getBoat();
        getData.then(function (emp) {
            $scope.LstBoat = emp.data;
        },function () {
            alert('Error in getting records');
        });
    }

    //var post = $http({
    //    method: "POST",
    //    url: "/RegisterBoat/GetBoat",
    //    dataType: 'json',
    //    headers: { "Content-Type": "application/json" }
    //});
    //post.then(function (data) {
    //    var data = JSON.parse(data);
    //    $scope.LstBoat = data.data.Lst;
    //});

    
   

});