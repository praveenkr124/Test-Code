﻿app.controller("RentCalculationController", function ($scope, RentCalculation) {

    //GetBookBoat();

    $scope.GetPriceBoat= function () {
        
        
        var CalculateTimePrice = {
            TotalRentHour: 0,
            TotalRentPrice: 0,
            BoatNo: $scope.BoatNo,
        };
        var getData = RentCalculation.GetPriceBoat(CalculateTimePrice);
        getData.then(function (emp) {
            if (emp.data == 'Invalid Record')
                alert('Invalid Record');
            else
            $scope.AllBoat = emp.data;
           
            ClearFields();
        }, function () {
            alert('Error in adding record');
        });
    }

    //$scope.GetPriceBoat = function () {
    //    alert('hhh');
    //    var CalculateTimePrice = {
    //        TotalRentHour: 0,
    //        TotalRentPrice: 0,
    //        BoatNo: $scope.BoatNo,
    //    };
    //    var getData = RentCalculation.GetPriceBoat(CalculateTimePrice);
    //    getData.then(function (msg) {
            
    //        alert(msg.data);
    //        ClearFields();
    //    }, function () {
    //        alert('Error in adding record');
    //    });
    //}

    function ClearFields() {
        $scope.BoatNo = "";
       

    }
});