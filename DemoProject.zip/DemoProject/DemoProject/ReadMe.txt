Sqlserver Script File Name : script
change connection string db.cs file path DemoProject\DemoProject\DB