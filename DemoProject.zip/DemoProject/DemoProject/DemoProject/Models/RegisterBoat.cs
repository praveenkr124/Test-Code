﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoProject.Models
{
    public class RegisterBoat
    {
        public int BoatId { get; set; }

        public string BoatName { get; set; }

        public double HourlyRate { get; set; }
       // public  List<RegisterBoat>  Lst  { get; set; }
    }
}