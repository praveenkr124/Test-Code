﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;
using DemoProject.Models;

namespace DemoProject.DB
{
    public class db
    {
        SqlConnection con = new SqlConnection(@"Data Source=OMG;Initial Catalog=BoatDatabase;Uid=sa;pwd=1234;");



        public String SaveBoat(RegisterBoat rs)

        {

            SqlCommand com = new SqlCommand("SaveBoat", con);

            com.CommandType = CommandType.StoredProcedure;

            com.Parameters.AddWithValue("@BoatName", rs.BoatName);

            com.Parameters.AddWithValue("@HourlyRate", rs.HourlyRate);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            return Convert.ToString(ds.Tables[0].Rows[0][0]);


        }


        public List<RegisterBoat> GetBoat()

        {

            SqlCommand com = new SqlCommand("GetBoat", con);

            com.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);
            
            List<RegisterBoat> lstObj = new List<RegisterBoat>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                RegisterBoat obj = new RegisterBoat();
                obj.BoatId = Convert.ToInt32(row["ID"]);
                obj.BoatName= Convert.ToString(row["BoatName"]);
                obj.HourlyRate = Convert.ToDouble(row["HourlyRate"]);
                lstObj.Add(obj);
            }

            return lstObj;
          
        }

        public string SaveBookBoat(BookBoat bk)

        {

            SqlCommand com = new SqlCommand("SaveBookBoat", con);

            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@BoatNo", bk.BoatNo);
            com.Parameters.AddWithValue("@CustomerName", bk.CustomerName);
            com.Parameters.AddWithValue("@RentedHour", bk.RentedHour);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            return Convert.ToString(ds.Tables[0].Rows[0][0]);

        }


        public List<BookBoat> GetBookBoat()

        {

            SqlCommand com = new SqlCommand("GetBookBoat", con);

            com.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);
            
            List<BookBoat> lstObj = new List<BookBoat>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                BookBoat obj = new BookBoat();
                obj.BoatNo = Convert.ToInt32(row["BoatNo"]);
                obj.CustomerName = Convert.ToString(row["CustomerName"]);
                obj.RentedHour = Convert.ToDouble(row["RentedHour"]);
                lstObj.Add(obj);
            }

            return lstObj;

        }

        public List<CalculateTimePrice> GetUpdateTimeAndRent(CalculateTimePrice tp)

        {

            SqlCommand com = new SqlCommand("UpdateTimeAndRent", con);

            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@BoatNo", tp.BoatNo);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);
            CalculateTimePrice obj = new CalculateTimePrice();
            List<CalculateTimePrice> lstObj = new List<CalculateTimePrice>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {

                obj.TotalRentHour = Convert.ToDouble(row["TotalRentHour"]);
                obj.TotalRentPrice = Convert.ToDouble(row["TotalRentPrice"]);
                obj.BoatNo = Convert.ToInt32(row["BoatNo"]);
                lstObj.Add(obj);
            }

            return lstObj;

        }


    }
}