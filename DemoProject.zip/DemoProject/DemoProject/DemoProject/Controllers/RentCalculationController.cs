﻿using DemoProject.DB;
using DemoProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DemoProject.Controllers
{
    public class RentCalculationController : Controller
    {
        // GET: RentCalculation
        db _dblayer;
        public RentCalculationController()
        {
            _dblayer = new db();
        }
        public ActionResult Index()
        {
            return View();
        }
        
        public JsonResult getAll(CalculateTimePrice BoatNo)
        {

            var boatPrice = _dblayer.GetUpdateTimeAndRent(BoatNo);
            return Json(boatPrice, JsonRequestBehavior.AllowGet);

        }

        public JsonResult Getprice(CalculateTimePrice BN)
        {
            List<CalculateTimePrice> boatPrice = new List<CalculateTimePrice>();
            string boatList = string.Empty;
            if (BN.BoatNo != 0)
            {
                 boatPrice = _dblayer.GetUpdateTimeAndRent(BN);

            }
            else
            {
                return Json("Invalid Record", JsonRequestBehavior.AllowGet);
            }

            return Json(boatPrice, JsonRequestBehavior.AllowGet);
        }


    }
}