﻿app.controller('demoController', function ($scope) {
    $scope.Message = "Hello To AngularJS QuickStart";
});