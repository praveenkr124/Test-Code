﻿using DemoProject.DB;
using DemoProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DemoProject.Controllers
{
    public class BookBoatController : Controller
    {
        // GET: BookBoat
        db _dblayer;
        public BookBoatController()
        {
            _dblayer = new db();
        }
        public ActionResult Index()
        {
            return View();
        }

        public string BookBoat(BookBoat bk)
        {
            string boatList = string.Empty;
            if (bk != null)
            {
                boatList =  _dblayer.SaveBookBoat(bk);

            }
            else
            {
                return "Invalid Record";
            }

            return boatList;
        }

        public JsonResult getAll()
        {

            var boatBookList = _dblayer.GetBookBoat();
            return Json(boatBookList, JsonRequestBehavior.AllowGet);

        }


    }
}