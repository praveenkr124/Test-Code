﻿app.controller("RegisterBoatController", function ($scope, MyService) {
 
    GetAllBoat();
   
    function GetAllBoat() {
       
        var getData = MyService.getBoat();
      
        getData.then(function (emp) {
            $scope.AllBoat = emp.data;
        },function () {
            alert('Error in getting records');
        });
    }

  
    $scope.AddBoat = function () {
        var RegisterBoat = {
            BoatName: $scope.BoatName,
            HourlyRate: $scope.HourlyRate,

        };
        var getData = MyService.AddBoat(RegisterBoat);
        getData.then(function (msg) {
            GetAllBoat();
            alert(msg.data);
            ClearFields();
        }, function () {
            alert('Error in adding record');
        });
        
    }
   

    function ClearFields() {
        $scope.BoatName = "";
        $scope.HourlyRate = "";
        
    }
});