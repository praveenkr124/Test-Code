﻿app.service("angularService", function ($http) {

    //get All Boat
    this.getBoat = function () {
        return $http.get("/RegisterBoat/GetBoat");
    };

   
});